package com.example.loginapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButton

class MainActivity : AppCompatActivity() {
    @Override
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val username = findViewById<View>(R.id.username) as TextView
        val password = findViewById<View>(R.id.password) as TextView
        val loginbtn = findViewById<View>(R.id.loginbtn) as MaterialButton
        val loginbtn1 = findViewById<View>(R.id.loginbtn1) as MaterialButton
        val loginbtn2 = findViewById<View>(R.id.loginbtn2) as MaterialButton
        val loginbtn3 = findViewById<View>(R.id.loginbtn3) as MaterialButton
        loginbtn.setOnClickListener {
            var openURL= Intent(android.content.Intent.ACTION_VIEW)
            openURL.data= Uri.parse("https://www.amazon.in/")
            startActivity(openURL)
        }
        loginbtn1.setOnClickListener {
            var openURL= Intent(android.content.Intent.ACTION_VIEW)
            openURL.data= Uri.parse("https://www.flipkart.com/")
            startActivity(openURL)
        }
        loginbtn2.setOnClickListener {
            var openURL= Intent(android.content.Intent.ACTION_VIEW)
            openURL.data= Uri.parse("https://www.myntra.com/")
            startActivity(openURL)
        }
        loginbtn3.setOnClickListener {
            var openURL= Intent(android.content.Intent.ACTION_VIEW)
            openURL.data= Uri.parse("https://www.google.com/")
            startActivity(openURL)
        }
    }
}